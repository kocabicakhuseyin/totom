package com.example.repository

import android.content.Context
import com.example.BuildConfig
import com.example.model.CouponPoolEvaluator
import com.example.model.MatchLiveScore
import com.example.model.MatchStatus
import com.example.model.PredictionOutcome
import com.example.model.TotoMatch
import com.example.network.ApiFootballLiveFixture
import com.example.network.ApiFootballLiveResponse
import com.example.network.ApiFootballLiveService
import com.example.network.EspnEvent
import com.example.network.EspnSoccerService
import com.example.network.NetworkModule
import com.example.network.ScoreCardsLiveService
import com.example.network.SporTotoApiService
import com.example.network.resolveStatus
import com.example.network.toMatchLiveScore
import com.example.network.model.BulletinMatchDto
import com.example.network.model.LiveBettingOddsDto
import com.example.network.model.MatchProbabilitiesDto
import com.example.network.model.NO_NEW_BULLETIN_ERROR
import com.example.network.model.PastBulletinMatchResult
import com.example.network.model.PreviousWeekBulletinReport
import com.example.network.model.WeeklyBulletinResponse
import com.example.network.model.isPlayable
import com.example.network.model.toDomainTotoMatch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class LiveScoreSource(
    val displayName: String,
    val badgeLabel: String
) {
    ESPN("ESPN (Ücretsiz • Anahtarsız)", "ESPN"),
    API_FOOTBALL("API-FOOTBALL (Free)", "API-Football")
}

class NoNewBulletinException(
    message: String = NO_NEW_BULLETIN_ERROR
) : IllegalStateException(message)

/**
 * Repository interface for managing weekly Spor Toto bulletin, matches, dates, live odds, and real-time scores.
 */
interface SporTotoBulletinRepository {
    val cachedBulletin: StateFlow<WeeklyBulletinResponse?>
    val liveScores: StateFlow<List<MatchLiveScore>>
    val liveScoreProvider: StateFlow<String>
    val activeLiveScoreSource: StateFlow<LiveScoreSource>
        get() = DEFAULT_SOURCE

    fun setLiveScoreSource(source: LiveScoreSource) {}
    fun requiresApiKeyForActiveSource(): Boolean =
        activeLiveScoreSource.value == LiveScoreSource.API_FOOTBALL

    /** Free API-Football settings. Implementations used by tests may omit these. */
    fun hasApiFootballKey(): Boolean = false
    fun configureApiFootballKey(key: String) {}
    fun freeScoreRequestsRemaining(): Int? = null

    /**
     * Fetches current weekly bulletin from external API (or returns cached if available).
     */
    suspend fun getWeeklyBulletin(forceRefresh: Boolean = false): Result<WeeklyBulletinResponse>

    /**
     * Fetches a specific weekly bulletin by week number.
     */
    suspend fun getBulletinByWeek(weekNumber: Int): Result<WeeklyBulletinResponse>

    /**
     * Refreshes real-time live betting odds for the current 15 matches.
     */
    suspend fun refreshLiveOdds(): Result<List<BulletinMatchDto>>

    /**
     * Polls the latest real-time match results and scores for the 15 matches.
     */
    suspend fun pollLiveScores(): Result<List<MatchLiveScore>>

    /**
     * Retrieves the 15 matches mapped to the domain TotoMatch model.
     */
    suspend fun getDomainMatches(forceRefresh: Boolean = false): Result<List<TotoMatch>>

    /**
     * Synchronizes the 15-match Spor Toto bulletin with Turkish League & European fixtures
     * from the active provider and immediately updates aligned live/finished scores.
     */
    suspend fun syncTurkishLeagueBulletinFromApi(): Result<WeeklyBulletinResponse> =
        Result.failure(IllegalStateException("Desteklenmiyor"))

    val previousWeekReport: StateFlow<PreviousWeekBulletinReport?>
        get() = EMPTY_PREVIOUS_WEEK

    /**
     * Fetches verified finished fixtures and final scores for the previous week's bulletin window.
     */
    suspend fun fetchPreviousWeekBulletinAndResults(
        forceRefresh: Boolean = false
    ): Result<PreviousWeekBulletinReport> =
        Result.failure(IllegalStateException("Desteklenmiyor"))

    companion object {
        val EMPTY_PREVIOUS_WEEK: StateFlow<PreviousWeekBulletinReport?> =
            MutableStateFlow<PreviousWeekBulletinReport?>(null).asStateFlow()
        val DEFAULT_SOURCE: StateFlow<LiveScoreSource> =
            MutableStateFlow(LiveScoreSource.API_FOOTBALL).asStateFlow()
    }
}

/**
 * Concrete implementation of SporTotoBulletinRepository utilizing Retrofit.
 */
class SporTotoBulletinRepositoryImpl(
    private val apiService: SporTotoApiService = NetworkModule.apiService,
    private val liveScoreService: ApiFootballLiveService = NetworkModule.liveScoreService,
    private val liveScoreApiKey: String = BuildConfig.API_FOOTBALL_KEY,
    // Retained as constructor options for compatibility with older callers.
    private val scoreCardsService: ScoreCardsLiveService = NetworkModule.scoreCardsService,
    private val trackedLeagueIds: List<Int> = listOf(203, 204, 39, 140, 135, 78, 61, 5),
    applicationContext: Context? = null,
    private val preferTurkishLeagueBulletin: Boolean = false,
    private val espnService: EspnSoccerService = NetworkModule.espnService,
    private val espnLeagueSlugs: List<String> = DEFAULT_ESPN_LEAGUES,
    initialSource: LiveScoreSource = LiveScoreSource.API_FOOTBALL
) : SporTotoBulletinRepository {

    companion object {
        /** Keep 20 of the Free plan's 100 daily calls in reserve. */
        const val FREE_DAILY_REQUEST_BUDGET = 80
        /** Free mode checks scores at most every three minutes per device. */
        const val FREE_MIN_POLL_INTERVAL_MS = 3 * 60 * 1000L
        /** Keyless ESPN cooldown to avoid duplicate rapid-fire requests. */
        const val ESPN_MIN_POLL_INTERVAL_MS = 60 * 1000L
        /** API-Football League IDs: Trendyol Süper Lig & TFF 1. Lig. */
        const val LEAGUE_TURKEY_SUPER_LIG = 203
        const val LEAGUE_TURKEY_FIRST_LIG = 204
        val DEFAULT_ESPN_LEAGUES = listOf(
            "tur.1",
            "eng.1",
            "esp.1",
            "ger.1",
            "ita.1",
            "fra.1",
            "uefa.nations",
            "uefa.champions"
        )
    }

    private val preferences = applicationContext?.applicationContext
        ?.getSharedPreferences("api_football_free", Context.MODE_PRIVATE)
    @Volatile private var configuredApiKey: String =
        preferences?.getString("api_key", null)?.trim().orEmpty()
            .ifBlank { liveScoreApiKey.trim() }
    @Volatile private var quotaDay: String = preferences?.getString("quota_day", "").orEmpty()
    @Volatile private var usedToday: Int = preferences?.getInt("used_today", 0) ?: 0
    @Volatile private var lastAttemptMs: Long = preferences?.getLong("last_attempt", 0L) ?: 0L
    @Volatile private var providerRemaining: Int? =
        preferences?.getInt("provider_remaining", -1)?.takeIf { it >= 0 }
    private var lastSuccessfulRequestMs = 0L
    private var lastEspnAttemptMs = 0L
    private var lastSuccessfulEspnMs = 0L
    private val pollMutex = Mutex()
    private val finishedDateFixturesCache = mutableMapOf<String, List<MatchLiveScore>>()

    private val _cachedBulletin = MutableStateFlow<WeeklyBulletinResponse?>(null)
    override val cachedBulletin: StateFlow<WeeklyBulletinResponse?> = _cachedBulletin.asStateFlow()

    private val _liveScores = MutableStateFlow<List<MatchLiveScore>>(emptyList())
    override val liveScores: StateFlow<List<MatchLiveScore>> = _liveScores.asStateFlow()

    private val _activeLiveScoreSource = MutableStateFlow(
        preferences?.getString("live_score_source", null)?.let { saved ->
            LiveScoreSource.values().firstOrNull { it.name == saved }
        } ?: initialSource
    )
    override val activeLiveScoreSource: StateFlow<LiveScoreSource> = _activeLiveScoreSource.asStateFlow()

    private val _liveScoreProvider = MutableStateFlow(_activeLiveScoreSource.value.displayName)
    override val liveScoreProvider: StateFlow<String> = _liveScoreProvider.asStateFlow()

    private val _previousWeekReport = MutableStateFlow<PreviousWeekBulletinReport?>(null)
    override val previousWeekReport: StateFlow<PreviousWeekBulletinReport?> = _previousWeekReport.asStateFlow()

    override fun setLiveScoreSource(source: LiveScoreSource) {
        if (_activeLiveScoreSource.value != source) {
            _activeLiveScoreSource.value = source
            _liveScoreProvider.value = source.displayName
            _liveScores.value = emptyList()
            _previousWeekReport.value = null
            lastAttemptMs = 0L
            lastSuccessfulRequestMs = 0L
            lastEspnAttemptMs = 0L
            lastSuccessfulEspnMs = 0L
            finishedDateFixturesCache.clear()
            preferences?.edit()?.putString("live_score_source", source.name)?.apply()
        }
    }

    override fun requiresApiKeyForActiveSource(): Boolean =
        _activeLiveScoreSource.value == LiveScoreSource.API_FOOTBALL

    override fun hasApiFootballKey(): Boolean = configuredApiKey.isNotBlank()

    override fun configureApiFootballKey(key: String) {
        val normalized = key.trim()
        if (normalized != configuredApiKey) {
            configuredApiKey = normalized
            usedToday = 0
            lastAttemptMs = 0L
            lastSuccessfulRequestMs = 0L
            providerRemaining = null
            finishedDateFixturesCache.clear()
            _liveScores.value = emptyList()
            _previousWeekReport.value = null
            preferences?.edit()
                ?.putString("api_key", normalized)
                ?.putInt("used_today", 0)
                ?.putLong("last_attempt", 0L)
                ?.putInt("provider_remaining", -1)
                ?.apply()
        }
    }

    override fun freeScoreRequestsRemaining(): Int? {
        if (!hasApiFootballKey()) return null
        val today = utcDay()
        val localRemaining = if (today == quotaDay) {
            (FREE_DAILY_REQUEST_BUDGET - usedToday).coerceAtLeast(0)
        } else FREE_DAILY_REQUEST_BUDGET
        return minOf(localRemaining, providerRemaining ?: 100)
    }

    private fun utcDay(): String = SimpleDateFormat("yyyyMMdd", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    private fun persistQuota() {
        preferences?.edit()
            ?.putString("quota_day", quotaDay)
            ?.putInt("used_today", usedToday)
            ?.putLong("last_attempt", lastAttemptMs)
            ?.putInt("provider_remaining", providerRemaining ?: -1)
            ?.apply()
    }

    private fun refreshDailyQuota() {
        val today = utcDay()
        if (quotaDay != today) {
            quotaDay = today
            usedToday = 0
            lastAttemptMs = 0L
            providerRemaining = null
            persistQuota()
        }
    }

    /**
     * API-Football is the only live-score source. Free quota is tracked locally
     * and provider response headers are also honored. Scores and minutes are
     * taken verbatim from the authenticated API; no fallback or mock games.
     */
    override suspend fun pollLiveScores(): Result<List<MatchLiveScore>> =
        withContext(Dispatchers.IO) {
            pollMutex.withLock {
                if (_activeLiveScoreSource.value == LiveScoreSource.ESPN) {
                    return@withLock pollLiveScoresFromEspnLocked()
                }
                fun unavailable(message: String): Result<List<MatchLiveScore>> {
                    _liveScores.value = emptyList()
                    return Result.failure(IllegalStateException(message))
                }

                val key = configuredApiKey
                if (key.isBlank()) {
                    return@withLock unavailable(
                        "Canlı skor için ücretsiz API-Football anahtarınızı girin."
                    )
                }
                refreshDailyQuota()
                val now = System.currentTimeMillis()
                if (lastAttemptMs > 0L && now - lastAttemptMs < FREE_MIN_POLL_INTERVAL_MS) {
                    return@withLock if (lastSuccessfulRequestMs == lastAttemptMs) {
                        Result.success(_liveScores.value)
                    } else {
                        unavailable("Ücretsiz kotayı korumak için 3 dakika bekleyip tekrar deneyin.")
                    }
                }
                if (usedToday >= FREE_DAILY_REQUEST_BUDGET || providerRemaining == 0) {
                    return@withLock unavailable(
                        "API-Football ücretsiz günlük sorgu sınırına ulaşıldı. " +
                            "Kota 00:00 UTC'de yenilenir."
                    )
                }

                // Count attempts too; invalid keys and HTTP errors can consume quota.
                lastAttemptMs = now

                try {
                    val bulletinMatches = _cachedBulletin.value?.matches.orEmpty().map { it.toDomainTotoMatch() }
                    val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
                    val todayIstanbul = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                        timeZone = istanbulTz
                    }.format(Date(now))
                    val eligibleDates = if (bulletinMatches.isNotEmpty()) {
                        extractEligibleBulletinDates(bulletinMatches, todayIstanbul, now)
                    } else {
                        emptyList()
                    }

                    val collectedRawScores = mutableListOf<MatchLiveScore>()

                    if (eligibleDates.isNotEmpty()) {
                        val weekKey = _cachedBulletin.value?.weekNumber ?: 0
                        for (dateStr in eligibleDates) {
                            val cacheKey = "$weekKey|$dateStr"
                            val cachedPast = if (dateStr < todayIstanbul) finishedDateFixturesCache[cacheKey] else null
                            if (cachedPast != null) {
                                collectedRawScores.addAll(cachedPast)
                                continue
                            }

                            if (usedToday >= FREE_DAILY_REQUEST_BUDGET || providerRemaining == 0) {
                                return@withLock unavailable(
                                    "API-Football ücretsiz günlük sorgu sınırına ulaşıldı. Kota 00:00 UTC'de yenilenir."
                                )
                            }
                            usedToday++
                            persistQuota()

                            val response = liveScoreService.getFixturesByDate(key, dateStr, "Europe/Istanbul")
                            response.headers()["x-ratelimit-requests-remaining"]
                                ?.toIntOrNull()?.let { providerRemaining = it.coerceAtLeast(0) }
                            persistQuota()

                            val body = response.body()
                            if (!response.isSuccessful || body == null) {
                                val problem = when (response.code()) {
                                    401, 403 -> "API-Football anahtarı geçersiz veya erişim izni yok."
                                    429 -> "API-Football ücretsiz istek kotası doldu."
                                    else -> "API-Football yanıt vermedi (HTTP ${response.code()})."
                                }
                                return@withLock unavailable(problem)
                            }
                            val providerErrors = body.errors
                            if ((providerErrors is Map<*, *> && providerErrors.isNotEmpty()) ||
                                (providerErrors is List<*> && providerErrors.isNotEmpty())
                            ) {
                                return@withLock unavailable(
                                    "API-Football isteği reddetti. Anahtarınızı ve ücretsiz plan kotanızı kontrol edin."
                                )
                            }

                            val parsedForDate = parseApiFootballFixtures(body)
                            val bulletinForDate = CouponPoolEvaluator.filterAndAlignToBulletin(
                                matches = bulletinMatches,
                                liveScores = parsedForDate
                            )
                            if (dateStr < todayIstanbul &&
                                parsedForDate.isNotEmpty() &&
                                bulletinForDate.none { it.isLive }
                            ) {
                                // Past bulletin day with only finished matches: cache to protect free quota.
                                finishedDateFixturesCache[cacheKey] = bulletinForDate
                            }
                            collectedRawScores.addAll(parsedForDate)
                        }
                    } else {
                        usedToday++
                        persistQuota()

                        val response = liveScoreService.getLiveFixtures(key)
                        response.headers()["x-ratelimit-requests-remaining"]
                            ?.toIntOrNull()?.let { providerRemaining = it.coerceAtLeast(0) }
                        persistQuota()
                        val body = response.body()
                        if (!response.isSuccessful || body == null) {
                            val problem = when (response.code()) {
                                401, 403 -> "API-Football anahtarı geçersiz veya erişim izni yok."
                                429 -> "API-Football ücretsiz istek kotası doldu."
                                else -> "API-Football yanıt vermedi (HTTP ${response.code()})."
                            }
                            return@withLock unavailable(problem)
                        }
                        val providerErrors = body.errors
                        if ((providerErrors is Map<*, *> && providerErrors.isNotEmpty()) ||
                            (providerErrors is List<*> && providerErrors.isNotEmpty())
                        ) {
                            return@withLock unavailable(
                                "API-Football isteği reddetti. Anahtarınızı ve ücretsiz plan kotanızı kontrol edin."
                            )
                        }
                        collectedRawScores.addAll(parseApiFootballFixtures(body))
                    }

                    val distinctRaw = collectedRawScores.distinctBy { it.matchNumber }
                    val actualScores = if (bulletinMatches.isNotEmpty()) {
                        CouponPoolEvaluator.filterAndAlignToBulletin(bulletinMatches, distinctRaw)
                    } else {
                        distinctRaw.sortedWith(
                            compareByDescending<MatchLiveScore> { it.isLive }
                                .thenByDescending { it.matchDate }
                        )
                    }

                    _liveScoreProvider.value = "API-FOOTBALL (Free)"
                    _liveScores.value = actualScores
                    lastSuccessfulRequestMs = lastAttemptMs
                    Result.success(actualScores)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    unavailable("API-Football bağlantısı kurulamadı. İnterneti kontrol edin.")
                }
            }
        }

    private fun parseApiFootballFixtures(body: ApiFootballLiveResponse): List<MatchLiveScore> {
        return body.response.mapNotNull { item ->
            val status = when (item.fixture.status.short.uppercase()) {
                "HT" -> MatchStatus.HALF_TIME
                "FT", "AET", "PEN" -> MatchStatus.FINISHED
                "1H", "2H", "ET", "BT", "P", "LIVE", "INT", "SUSP" -> MatchStatus.LIVE
                else -> MatchStatus.UPCOMING
            }
            if (status == MatchStatus.UPCOMING) return@mapNotNull null
            MatchLiveScore(
                matchNumber = item.fixture.id,
                homeTeam = item.teams.home.name,
                awayTeam = item.teams.away.name,
                homeScore = item.goals.home,
                awayScore = item.goals.away,
                status = status,
                minuteText = when {
                    status == MatchStatus.HALF_TIME -> "İY"
                    status == MatchStatus.FINISHED -> "MS"
                    item.fixture.status.elapsed != null -> "${item.fixture.status.elapsed}'"
                    else -> "—"
                },
                matchDate = item.fixture.date.orEmpty(),
                league = item.league?.name.orEmpty()
            )
        }
    }

    private fun extractEligibleBulletinDates(
        bulletinMatches: List<TotoMatch>,
        todayIstanbul: String,
        nowMs: Long
    ): List<String> {
        val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = istanbulTz }
        val inputPatterns = listOf("dd.MM.yyyy HH:mm", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ssXXX")
        val cutoffPastMs = nowMs - 10L * 24 * 60 * 60 * 1000L

        return bulletinMatches.mapNotNull { match ->
            val raw = match.matchDate.trim()
            if (raw.isEmpty()) return@mapNotNull null
            val parsedMs = inputPatterns.firstNotNullOfOrNull { pattern ->
                try {
                    SimpleDateFormat(pattern, Locale.ROOT).apply {
                        isLenient = false
                        timeZone = istanbulTz
                    }.parse(raw)?.time
                } catch (_: Exception) {
                    null
                }
            } ?: return@mapNotNull null
            val dayStr = dayFmt.format(Date(parsedMs))
            if ((dayStr <= todayIstanbul || parsedMs <= nowMs) && parsedMs >= cutoffPastMs) {
                dayStr
            } else {
                null
            }
        }.distinct().sorted().takeLast(5)
    }

    private fun defaultOfflineBulletin(
        weekNumber: Int = if (preferTurkishLeagueBulletin) 39 else 38
    ): WeeklyBulletinResponse =
        if (preferTurkishLeagueBulletin) {
            NetworkModule.createTurkishLeagueSporTotoBulletin(weekNumber)
        } else {
            NetworkModule.createFallbackBulletin(weekNumber)
        }

    override suspend fun syncTurkishLeagueBulletinFromApi(): Result<WeeklyBulletinResponse> =
        withContext(Dispatchers.IO) {
            pollMutex.withLock {
                if (_activeLiveScoreSource.value == LiveScoreSource.ESPN) {
                    return@withLock syncTurkishLeagueBulletinFromEspnLocked()
                }
                val key = configuredApiKey
                if (key.isBlank()) {
                    return@withLock Result.failure(
                        IllegalStateException(
                            "Türkiye Ligi maçlarını API'den çekmek için önce Canlı sekmesinden API-Football anahtarınızı girin."
                        )
                    )
                }
                refreshDailyQuota()
                if (usedToday >= FREE_DAILY_REQUEST_BUDGET || providerRemaining == 0) {
                    return@withLock Result.failure(
                        IllegalStateException(
                            "API-Football ücretsiz günlük sorgu sınırına ulaşıldı. Kota 00:00 UTC'de yenilenir."
                        )
                    )
                }

                try {
                    val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
                    val now = System.currentTimeMillis()
                    val cal = java.util.Calendar.getInstance(istanbulTz).apply { timeInMillis = now }
                    val year = cal.get(java.util.Calendar.YEAR)
                    val month = cal.get(java.util.Calendar.MONTH) + 1
                    val season = if (month >= 7) year else year - 1
                    val isoDayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = istanbulTz }
                    val fromCal = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, -2) }
                    val toCal = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, 9) }
                    val fromDate = isoDayFmt.format(fromCal.time)
                    val toDate = isoDayFmt.format(toCal.time)

                    suspend fun fetchLeague(leagueId: Int): Result<ApiFootballLiveResponse> {
                        if (usedToday >= FREE_DAILY_REQUEST_BUDGET || providerRemaining == 0) {
                            return Result.failure(
                                IllegalStateException(
                                    "API-Football ücretsiz günlük sorgu sınırına ulaşıldı. Kota 00:00 UTC'de yenilenir."
                                )
                            )
                        }
                        usedToday++
                        persistQuota()
                        val response = liveScoreService.getFixturesByLeague(
                            apiKey = key,
                            leagueId = leagueId,
                            season = season,
                            fromDate = fromDate,
                            toDate = toDate,
                            timezone = "Europe/Istanbul"
                        )
                        response.headers()["x-ratelimit-requests-remaining"]
                            ?.toIntOrNull()?.let { providerRemaining = it.coerceAtLeast(0) }
                        persistQuota()

                        val body = response.body()
                        if (!response.isSuccessful || body == null) {
                            val problem = when (response.code()) {
                                401, 403 -> "API-Football anahtarı geçersiz veya erişim izni yok."
                                429 -> "API-Football ücretsiz istek kotası doldu."
                                else -> "API-Football yanıt vermedi (HTTP ${response.code()})."
                            }
                            return Result.failure(IllegalStateException(problem))
                        }
                        val providerErrors = body.errors
                        if ((providerErrors is Map<*, *> && providerErrors.isNotEmpty()) ||
                            (providerErrors is List<*> && providerErrors.isNotEmpty())
                        ) {
                            return Result.failure(
                                IllegalStateException(
                                    "API-Football isteği reddetti. Anahtarınızı ve ücretsiz plan kotanızı kontrol edin."
                                )
                            )
                        }
                        return Result.success(body)
                    }

                    val rawResponses = mutableListOf<ApiFootballLiveResponse>()
                    val superLigBody = fetchLeague(LEAGUE_TURKEY_SUPER_LIG).getOrElse {
                        return@withLock Result.failure(it)
                    }
                    rawResponses.add(superLigBody)
                    val superLigFixtures = superLigBody.response
                        .sortedBy { it.fixture.date.orEmpty() }

                    val firstLigFixtures = if (superLigFixtures.size < 15 &&
                        usedToday < FREE_DAILY_REQUEST_BUDGET &&
                        providerRemaining != 0
                    ) {
                        val res = fetchLeague(LEAGUE_TURKEY_FIRST_LIG)
                        res.getOrNull()?.let { body ->
                            rawResponses.add(body)
                            body.response.sortedBy { it.fixture.date.orEmpty() }
                        }.orEmpty()
                    } else {
                        emptyList()
                    }

                    val selectedFixtures = buildList {
                        addAll(superLigFixtures.take(10))
                        val remainingSlots = 15 - size
                        if (remainingSlots > 0) {
                            addAll(
                                firstLigFixtures
                                    .filter { f -> none { it.fixture.id == f.fixture.id } }
                                    .take(remainingSlots)
                            )
                        }
                        if (size < 15) {
                            addAll(
                                superLigFixtures
                                    .filter { f -> none { it.fixture.id == f.fixture.id } }
                                    .take(15 - size)
                            )
                        }
                    }.sortedBy { it.fixture.date.orEmpty() }

                    val bulletinMatches = mutableListOf<BulletinMatchDto>()
                    selectedFixtures.forEachIndexed { idx, fixture ->
                        bulletinMatches.add(fixture.toBulletinMatchDto(idx + 1, istanbulTz))
                    }

                    if (bulletinMatches.size < 15) {
                        val fallbackMatches = NetworkModule.createTurkishLeagueSporTotoBulletin().matches
                        val existingPairs = bulletinMatches.map {
                            "${it.homeTeam.lowercase(Locale.ROOT)}|${it.awayTeam.lowercase(Locale.ROOT)}"
                        }.toMutableSet()
                        for (candidate in fallbackMatches) {
                            if (bulletinMatches.size >= 15) break
                            val pair = "${candidate.homeTeam.lowercase(Locale.ROOT)}|${candidate.awayTeam.lowercase(Locale.ROOT)}"
                            if (existingPairs.add(pair)) {
                                bulletinMatches.add(candidate.copy(matchNumber = bulletinMatches.size + 1))
                            }
                        }
                    }

                    val finalMatches = bulletinMatches.take(15).mapIndexed { index, dto ->
                        dto.copy(matchNumber = index + 1)
                    }
                    val weekNum = cal.get(java.util.Calendar.WEEK_OF_YEAR).coerceIn(1, 53)
                    val startDate = finalMatches.firstOrNull()?.matchDate?.substringBefore(" ")
                        ?: SimpleDateFormat("dd.MM.yyyy", Locale.US).apply { timeZone = istanbulTz }.format(Date(now))
                    val endDate = finalMatches.lastOrNull()?.matchDate?.substringBefore(" ") ?: startDate

                    val bulletin = WeeklyBulletinResponse(
                        weekNumber = weekNum,
                        season = "$season-${season + 1}",
                        bulletinTitle = "Türkiye Ligi Spor Toto $weekNum. Hafta (API)",
                        startDate = startDate,
                        endDate = endDate,
                        jackpotEstimateTL = 0.0,
                        isActive = true,
                        matches = finalMatches
                    )
                    _cachedBulletin.value = bulletin

                    // Immediately update live/finished scores from the fetched Turkish league fixtures
                    val parsedScores = rawResponses
                        .flatMap { parseApiFootballFixtures(it) }
                        .distinctBy { it.matchNumber }
                    val domainMatches = finalMatches.map { it.toDomainTotoMatch() }
                    val aligned = CouponPoolEvaluator.filterAndAlignToBulletin(domainMatches, parsedScores)
                    _liveScoreProvider.value = "API-FOOTBALL (Free)"
                    _liveScores.value = aligned

                    Result.success(bulletin)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    Result.failure(
                        IllegalStateException("Türkiye Ligi API-Football bağlantısı kurulamadı. İnterneti kontrol edin.")
                    )
                }
            }
        }

    override suspend fun fetchPreviousWeekBulletinAndResults(
        forceRefresh: Boolean
    ): Result<PreviousWeekBulletinReport> =
        withContext(Dispatchers.IO) {
            pollMutex.withLock {
                if (!forceRefresh) {
                    _previousWeekReport.value?.let { cached ->
                        return@withLock Result.success(cached)
                    }
                }

                if (_activeLiveScoreSource.value == LiveScoreSource.ESPN) {
                    return@withLock fetchPreviousWeekFromEspnLocked()
                }

                val key = configuredApiKey
                if (key.isBlank()) {
                    return@withLock Result.failure(
                        IllegalStateException(
                            "Geçen haftanın bültenini ve doğrulanmış skor sonuçlarını çekmek için Canlı sekmesinden API-Football anahtarınızı girin."
                        )
                    )
                }
                refreshDailyQuota()
                if (usedToday >= FREE_DAILY_REQUEST_BUDGET || providerRemaining == 0) {
                    return@withLock Result.failure(
                        IllegalStateException(
                            "API-Football ücretsiz günlük sorgu sınırına ulaşıldı. Kota 00:00 UTC'de yenilenir."
                        )
                    )
                }

                try {
                    val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
                    val now = System.currentTimeMillis()
                    val cal = java.util.Calendar.getInstance(istanbulTz).apply { timeInMillis = now }
                    val year = cal.get(java.util.Calendar.YEAR)
                    val month = cal.get(java.util.Calendar.MONTH) + 1
                    val season = if (month >= 7) year else year - 1
                    val isoDayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = istanbulTz }
                    // Previous completed calendar week (Monday 00:00 through Sunday 23:59), Istanbul time.
                    val monday = (cal.clone() as java.util.Calendar).apply {
                        firstDayOfWeek = java.util.Calendar.MONDAY
                        val daysSinceMonday = (get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
                        add(java.util.Calendar.DAY_OF_MONTH, -daysSinceMonday)
                    }
                    val fromCal = (monday.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, -7) }
                    val toCal = (monday.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, -1) }
                    val fromDate = isoDayFmt.format(fromCal.time)
                    val toDate = isoDayFmt.format(toCal.time)

                    suspend fun queryLeague(leagueId: Int): Result<List<ApiFootballLiveFixture>> {
                        if (usedToday >= FREE_DAILY_REQUEST_BUDGET || providerRemaining == 0) {
                            return Result.failure(
                                IllegalStateException(
                                    "API-Football ücretsiz günlük sorgu sınırına ulaşıldı. Kota 00:00 UTC'de yenilenir."
                                )
                            )
                        }
                        usedToday++
                        persistQuota()
                        val response = liveScoreService.getFixturesByLeague(
                            apiKey = key,
                            leagueId = leagueId,
                            season = season,
                            fromDate = fromDate,
                            toDate = toDate,
                            timezone = "Europe/Istanbul"
                        )
                        response.headers()["x-ratelimit-requests-remaining"]
                            ?.toIntOrNull()?.let { providerRemaining = it.coerceAtLeast(0) }
                        persistQuota()

                        val body = response.body()
                        if (!response.isSuccessful || body == null) {
                            val problem = when (response.code()) {
                                401, 403 -> "API-Football anahtarı geçersiz veya erişim izni yok."
                                429 -> "API-Football ücretsiz istek kotası doldu."
                                else -> "API-Football yanıt vermedi (HTTP ${response.code()})."
                            }
                            return Result.failure(IllegalStateException(problem))
                        }
                        val providerErrors = body.errors
                        if ((providerErrors is Map<*, *> && providerErrors.isNotEmpty()) ||
                            (providerErrors is List<*> && providerErrors.isNotEmpty())
                        ) {
                            return Result.failure(
                                IllegalStateException(
                                    "API-Football isteği reddetti. Anahtarınızı ve ücretsiz plan kotanızı kontrol edin."
                                )
                            )
                        }
                        val finishedOnly = body.response.filter { item ->
                            val short = item.fixture.status.short.uppercase(Locale.ROOT)
                            short in setOf("FT", "AET", "PEN") &&
                                item.goals.home != null &&
                                item.goals.away != null
                        }.sortedBy { it.fixture.date.orEmpty() }
                        return Result.success(finishedOnly)
                    }

                    val superLig = queryLeague(LEAGUE_TURKEY_SUPER_LIG).getOrElse {
                        return@withLock Result.failure(it)
                    }
                    val firstLig = if (superLig.size < 15 &&
                        usedToday < FREE_DAILY_REQUEST_BUDGET &&
                        providerRemaining != 0
                    ) {
                        queryLeague(LEAGUE_TURKEY_FIRST_LIG).getOrNull().orEmpty()
                    } else {
                        emptyList()
                    }
                    val europeanTop = if (superLig.size + firstLig.size < 15 &&
                        usedToday < FREE_DAILY_REQUEST_BUDGET &&
                        providerRemaining != 0
                    ) {
                        queryLeague(39).getOrNull().orEmpty()
                    } else {
                        emptyList()
                    }

                    val picked = buildList {
                        addAll(superLig.take(10))
                        if (size < 15) {
                            addAll(firstLig.filter { f -> none { it.fixture.id == f.fixture.id } }.take(15 - size))
                        }
                        if (size < 15) {
                            addAll(superLig.filter { f -> none { it.fixture.id == f.fixture.id } }.take(15 - size))
                        }
                        if (size < 15) {
                            addAll(europeanTop.filter { f -> none { it.fixture.id == f.fixture.id } }.take(15 - size))
                        }
                    }.distinctBy { it.fixture.id }
                        .sortedBy { it.fixture.date.orEmpty() }
                        .take(15)

                    if (picked.isEmpty()) {
                        return@withLock Result.failure(
                            IllegalStateException(
                                "Geçen hafta ($fromDate - $toDate) için tamamlanmış API-Football maçı bulunamadı."
                            )
                        )
                    }

                    val mapped = picked.mapIndexed { idx, item ->
                        val homeGoals = item.goals.home
                        val awayGoals = item.goals.away
                        val winning = when {
                            homeGoals == null || awayGoals == null -> null
                            homeGoals > awayGoals -> PredictionOutcome.HOME
                            homeGoals == awayGoals -> PredictionOutcome.DRAW
                            else -> PredictionOutcome.AWAY
                        }
                        PastBulletinMatchResult(
                            matchNumber = idx + 1,
                            homeTeam = item.teams.home.name.uppercase(Locale.ROOT).trim(),
                            awayTeam = item.teams.away.name.uppercase(Locale.ROOT).trim(),
                            matchDate = formatIsoDateForBulletin(item.fixture.date, istanbulTz),
                            league = item.league?.name?.takeIf { it.isNotBlank() } ?: "Türkiye Ligi",
                            homeScore = homeGoals,
                            awayScore = awayGoals,
                            status = MatchStatus.FINISHED,
                            winningOutcome = winning
                        )
                    }

                    val currentWeek = _cachedBulletin.value?.weekNumber ?: cal.get(java.util.Calendar.WEEK_OF_YEAR)
                    val prevWeek = (currentWeek - 1).coerceAtLeast(1)
                    val firstDay = mapped.firstOrNull()?.matchDate?.substringBefore(" ") ?: fromDate
                    val lastDay = mapped.lastOrNull()?.matchDate?.substringBefore(" ") ?: toDate
                    val report = PreviousWeekBulletinReport(
                        weekNumber = prevWeek,
                        weekLabel = "Geçen Haftanın Maç Sonuçları",
                        dateRangeLabel = "$firstDay - $lastDay",
                        sourceLabel = "API-FOOTBALL • Doğrulanmış Sonuçlar",
                        matches = mapped
                    )
                    _previousWeekReport.value = report
                    Result.success(report)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    Result.failure(
                        IllegalStateException("Geçen haftanın sonuçları için API-Football bağlantısı kurulamadı.")
                    )
                }
            }
        }

    private fun ApiFootballLiveFixture.toBulletinMatchDto(
        matchNumber: Int,
        istanbulTz: TimeZone
    ): BulletinMatchDto {
        val formattedDate = formatIsoDateForBulletin(fixture.date, istanbulTz)
        val statusLabel = when (fixture.status.short.uppercase(Locale.ROOT)) {
            "FT", "AET", "PEN" -> "FINISHED"
            "1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT", "SUSP" -> "LIVE"
            else -> "UPCOMING"
        }
        val leagueLabel = league?.name?.takeIf { it.isNotBlank() } ?: "Türkiye Ligi"
        return BulletinMatchDto(
            matchNumber = matchNumber,
            homeTeam = teams.home.name.uppercase(Locale.ROOT).trim(),
            awayTeam = teams.away.name.uppercase(Locale.ROOT).trim(),
            matchDate = formattedDate,
            league = leagueLabel,
            venue = "",
            status = statusLabel,
            liveOdds = LiveBettingOddsDto(
                homeWinOdd = 2.15,
                drawOdd = 3.25,
                awayWinOdd = 3.30,
                doubleChance1X = 1.32,
                doubleChance12 = 1.28,
                doubleChanceX2 = 1.62
            ),
            probabilities = MatchProbabilitiesDto(
                homeProbability = 42,
                drawProbability = 29,
                awayProbability = 29
            )
        )
    }

    private fun formatIsoDateForBulletin(rawDate: String?, istanbulTz: TimeZone): String {
        val outFmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US).apply { timeZone = istanbulTz }
        if (rawDate.isNullOrBlank()) return outFmt.format(Date())
        val trimmed = rawDate.trim()
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mmXXX",
            "yyyy-MM-dd'T'HH:mm'Z'",
            "yyyy-MM-dd HH:mm:ss",
            "dd.MM.yyyy HH:mm"
        )
        val parsed = patterns.firstNotNullOfOrNull { pattern ->
            try {
                SimpleDateFormat(pattern, Locale.ROOT).apply {
                    isLenient = false
                    if (pattern.endsWith("'Z'")) {
                        timeZone = TimeZone.getTimeZone("UTC")
                    } else if (!pattern.contains("XXX")) {
                        timeZone = istanbulTz
                    }
                }.parse(trimmed)
            } catch (_: Exception) {
                null
            }
        }
        return outFmt.format(parsed ?: Date())
    }

    private fun espnLeagueLabel(slug: String, fallbackName: String?): String = when (slug) {
        "tur.1" -> "Trendyol Süper Lig"
        "eng.1" -> "İngiltere Premier Lig"
        "esp.1" -> "İspanya La Liga"
        "ger.1" -> "Almanya Bundesliga"
        "ita.1" -> "İtalya Serie A"
        "fra.1" -> "Fransa Ligue 1"
        "uefa.nations" -> "UEFA Uluslar Ligi"
        "uefa.champions" -> "UEFA Şampiyonlar Ligi"
        else -> fallbackName?.takeIf { it.isNotBlank() } ?: slug.uppercase(Locale.ROOT)
    }

    private suspend fun pollLiveScoresFromEspnLocked(): Result<List<MatchLiveScore>> {
        val now = System.currentTimeMillis()
        if (lastEspnAttemptMs > 0L && now - lastEspnAttemptMs < ESPN_MIN_POLL_INTERVAL_MS &&
            lastSuccessfulEspnMs == lastEspnAttemptMs
        ) {
            return Result.success(_liveScores.value)
        }
        lastEspnAttemptMs = now
        return try {
            val bulletinMatches = _cachedBulletin.value?.matches.orEmpty().map { it.toDomainTotoMatch() }
            val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
            val todayIstanbul = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = istanbulTz
            }.format(Date(now))
            val eligibleDates = if (bulletinMatches.isNotEmpty()) {
                extractEligibleBulletinDates(bulletinMatches, todayIstanbul, now)
            } else {
                emptyList()
            }
            val datesParam = if (eligibleDates.isNotEmpty()) {
                val startCompact = eligibleDates.first().replace("-", "")
                val endCompact = eligibleDates.last().replace("-", "")
                if (startCompact == endCompact) startCompact else "$startCompact-$endCompact"
            } else {
                null
            }

            var anySuccess = false
            val leagueResponses = coroutineScope {
                espnLeagueSlugs.map { slug ->
                    async {
                        try {
                            val response = espnService.getScoreboard(slug, datesParam)
                            if (response.isSuccessful && response.body() != null) {
                                slug to response.body()!!
                            } else {
                                null
                            }
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            null
                        }
                    }
                }.awaitAll()
            }

            val collectedRaw = mutableListOf<MatchLiveScore>()
            leagueResponses.filterNotNull().forEach { (slug, body) ->
                anySuccess = true
                val label = espnLeagueLabel(slug, body.leagues.firstOrNull()?.name)
                body.events.forEach { event ->
                    event.toMatchLiveScore(label)?.let { collectedRaw.add(it) }
                }
            }

            if (!anySuccess) {
                _liveScores.value = emptyList()
                return Result.failure(
                    IllegalStateException("ESPN bağlantısı kurulamadı. İnterneti kontrol edin.")
                )
            }

            val distinctRaw = collectedRaw.distinctBy { it.matchNumber }
            val actualScores = if (bulletinMatches.isNotEmpty()) {
                CouponPoolEvaluator.filterAndAlignToBulletin(bulletinMatches, distinctRaw)
            } else {
                distinctRaw.sortedWith(
                    compareByDescending<MatchLiveScore> { it.isLive }
                        .thenByDescending { it.matchDate }
                )
            }

            _liveScoreProvider.value = LiveScoreSource.ESPN.displayName
            _liveScores.value = actualScores
            lastSuccessfulEspnMs = lastEspnAttemptMs
            Result.success(actualScores)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            _liveScores.value = emptyList()
            Result.failure(IllegalStateException("ESPN bağlantısı kurulamadı. İnterneti kontrol edin."))
        }
    }

    private suspend fun syncTurkishLeagueBulletinFromEspnLocked(): Result<WeeklyBulletinResponse> {
        return try {
            val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
            val now = System.currentTimeMillis()
            val cal = java.util.Calendar.getInstance(istanbulTz).apply { timeInMillis = now }
            val year = cal.get(java.util.Calendar.YEAR)
            val month = cal.get(java.util.Calendar.MONTH) + 1
            val season = if (month >= 7) year else year - 1
            val compactFmt = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = istanbulTz }
            val fromCal = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, -2) }
            val toCal = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, 9) }
            val datesRange = "${compactFmt.format(fromCal.time)}-${compactFmt.format(toCal.time)}"

            val syncSlugs = listOf("tur.1", "ger.1", "fra.1", "eng.1", "esp.1", "ita.1", "uefa.nations")
            val results = coroutineScope {
                syncSlugs.map { slug ->
                    async {
                        try {
                            val response = espnService.getScoreboard(slug, datesRange)
                            if (response.isSuccessful && response.body() != null) {
                                slug to response.body()!!
                            } else {
                                null
                            }
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            null
                        }
                    }
                }.awaitAll()
            }.filterNotNull()

            if (results.isEmpty()) {
                return Result.failure(
                    IllegalStateException("ESPN Türkiye Ligi bağlantısı kurulamadı. İnterneti kontrol edin.")
                )
            }

            val superLigEvents = results.firstOrNull { it.first == "tur.1" }?.second?.events.orEmpty()
                .sortedBy { it.date.orEmpty() }
            val otherLeagueEvents = results.filter { it.first != "tur.1" }
                .flatMap { (slug, body) ->
                    val label = espnLeagueLabel(slug, body.leagues.firstOrNull()?.name)
                    body.events.map { it to label }
                }
                .sortedBy { it.first.date.orEmpty() }

            val pickedWithLeague = buildList<Pair<EspnEvent, String>> {
                superLigEvents.take(10).forEach { add(it to "Trendyol Süper Lig") }
                if (size < 15) {
                    otherLeagueEvents
                        .filter { (ev, _) -> none { it.first.id == ev.id && ev.id.isNotBlank() } }
                        .take(15 - size)
                        .forEach { add(it) }
                }
                if (size < 15) {
                    superLigEvents
                        .filter { ev -> none { it.first.id == ev.id && ev.id.isNotBlank() } }
                        .take(15 - size)
                        .forEach { add(it to "Trendyol Süper Lig") }
                }
            }.sortedBy { it.first.date.orEmpty() }

            val bulletinMatches = mutableListOf<BulletinMatchDto>()
            pickedWithLeague.forEachIndexed { idx, (event, leagueLabel) ->
                event.toBulletinMatchDto(idx + 1, leagueLabel, istanbulTz)?.let {
                    bulletinMatches.add(it)
                }
            }

            if (bulletinMatches.size < 15) {
                val fallbackMatches = NetworkModule.createTurkishLeagueSporTotoBulletin().matches
                val existingPairs = bulletinMatches.map {
                    "${it.homeTeam.lowercase(Locale.ROOT)}|${it.awayTeam.lowercase(Locale.ROOT)}"
                }.toMutableSet()
                for (candidate in fallbackMatches) {
                    if (bulletinMatches.size >= 15) break
                    val pair = "${candidate.homeTeam.lowercase(Locale.ROOT)}|${candidate.awayTeam.lowercase(Locale.ROOT)}"
                    if (existingPairs.add(pair)) {
                        bulletinMatches.add(candidate.copy(matchNumber = bulletinMatches.size + 1))
                    }
                }
            }

            val finalMatches = bulletinMatches.take(15).mapIndexed { index, dto ->
                dto.copy(matchNumber = index + 1)
            }
            val weekNum = cal.get(java.util.Calendar.WEEK_OF_YEAR).coerceIn(1, 53)
            val startDate = finalMatches.firstOrNull()?.matchDate?.substringBefore(" ")
                ?: SimpleDateFormat("dd.MM.yyyy", Locale.US).apply { timeZone = istanbulTz }.format(Date(now))
            val endDate = finalMatches.lastOrNull()?.matchDate?.substringBefore(" ") ?: startDate

            val bulletin = WeeklyBulletinResponse(
                weekNumber = weekNum,
                season = "$season-${season + 1}",
                bulletinTitle = "Türkiye Ligi Spor Toto $weekNum. Hafta (ESPN)",
                startDate = startDate,
                endDate = endDate,
                jackpotEstimateTL = 0.0,
                isActive = true,
                matches = finalMatches
            )
            _cachedBulletin.value = bulletin

            val parsedScores = results
                .flatMap { (slug, body) ->
                    val label = espnLeagueLabel(slug, body.leagues.firstOrNull()?.name)
                    body.events.mapNotNull { it.toMatchLiveScore(label) }
                }
                .distinctBy { it.matchNumber }
            val domainMatches = finalMatches.map { it.toDomainTotoMatch() }
            val aligned = CouponPoolEvaluator.filterAndAlignToBulletin(domainMatches, parsedScores)
            _liveScoreProvider.value = LiveScoreSource.ESPN.displayName
            _liveScores.value = aligned

            Result.success(bulletin)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.failure(
                IllegalStateException("ESPN Türkiye Ligi bağlantısı kurulamadı. İnterneti kontrol edin.")
            )
        }
    }

    private suspend fun fetchPreviousWeekFromEspnLocked(): Result<PreviousWeekBulletinReport> {
        return try {
            val istanbulTz = TimeZone.getTimeZone("Europe/Istanbul")
            val now = System.currentTimeMillis()
            val cal = java.util.Calendar.getInstance(istanbulTz).apply { timeInMillis = now }
            val compactFmt = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = istanbulTz }
            val displayDayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = istanbulTz }
            // Use the prior Monday-Sunday rather than a rolling 11-to-3-day range.
            val monday = (cal.clone() as java.util.Calendar).apply {
                firstDayOfWeek = java.util.Calendar.MONDAY
                val daysSinceMonday = (get(java.util.Calendar.DAY_OF_WEEK) + 5) % 7
                add(java.util.Calendar.DAY_OF_MONTH, -daysSinceMonday)
            }
            val fromCal = (monday.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, -7) }
            val toCal = (monday.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_MONTH, -1) }
            val datesRange = "${compactFmt.format(fromCal.time)}-${compactFmt.format(toCal.time)}"
            val fromDate = displayDayFmt.format(fromCal.time)
            val toDate = displayDayFmt.format(toCal.time)

            val querySlugs = listOf("tur.1", "eng.1", "esp.1", "ger.1", "ita.1", "fra.1", "uefa.nations")
            val results = coroutineScope {
                querySlugs.map { slug ->
                    async {
                        try {
                            val response = espnService.getScoreboard(slug, datesRange)
                            if (response.isSuccessful && response.body() != null) {
                                slug to response.body()!!
                            } else {
                                null
                            }
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (_: Exception) {
                            null
                        }
                    }
                }.awaitAll()
            }.filterNotNull()

            if (results.isEmpty()) {
                return Result.failure(
                    IllegalStateException("Geçen haftanın sonuçları için ESPN bağlantısı kurulamadı.")
                )
            }

            val finishedByLeague = results.map { (slug, body) ->
                val label = espnLeagueLabel(slug, body.leagues.firstOrNull()?.name)
                val finishedScores = body.events
                    .mapNotNull { it.toMatchLiveScore(label) }
                    .filter {
                        it.status == MatchStatus.FINISHED &&
                            it.homeScore != null &&
                            it.awayScore != null
                    }
                    .sortedBy { it.matchDate }
                slug to finishedScores
            }

            val superLig = finishedByLeague.firstOrNull { it.first == "tur.1" }?.second.orEmpty()
            val otherFinished = finishedByLeague.filter { it.first != "tur.1" }.flatMap { it.second }

            val picked = buildList {
                addAll(superLig.take(10))
                if (size < 15) {
                    addAll(
                        otherFinished
                            .filter { m -> none { it.matchNumber == m.matchNumber } }
                            .take(15 - size)
                    )
                }
                if (size < 15) {
                    addAll(
                        superLig
                            .filter { m -> none { it.matchNumber == m.matchNumber } }
                            .take(15 - size)
                    )
                }
            }.distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.matchDate}" }
                .sortedBy { it.matchDate }
                .take(15)

            if (picked.isEmpty()) {
                return Result.failure(
                    IllegalStateException(
                        "Geçen hafta ($fromDate - $toDate) için tamamlanmış ESPN maçı bulunamadı."
                    )
                )
            }

            val mapped = picked.mapIndexed { idx, score ->
                PastBulletinMatchResult(
                    matchNumber = idx + 1,
                    homeTeam = score.homeTeam.uppercase(Locale.ROOT).trim(),
                    awayTeam = score.awayTeam.uppercase(Locale.ROOT).trim(),
                    matchDate = formatIsoDateForBulletin(score.matchDate, istanbulTz),
                    league = score.league.ifBlank { "Türkiye Ligi" },
                    homeScore = score.homeScore,
                    awayScore = score.awayScore,
                    status = MatchStatus.FINISHED,
                    winningOutcome = score.winningOutcome
                )
            }

            val currentWeek = _cachedBulletin.value?.weekNumber ?: cal.get(java.util.Calendar.WEEK_OF_YEAR)
            val prevWeek = (currentWeek - 1).coerceAtLeast(1)
            val firstDay = mapped.firstOrNull()?.matchDate?.substringBefore(" ") ?: fromDate
            val lastDay = mapped.lastOrNull()?.matchDate?.substringBefore(" ") ?: toDate
            val report = PreviousWeekBulletinReport(
                weekNumber = prevWeek,
                weekLabel = "Geçen Haftanın Maç Sonuçları",
                dateRangeLabel = "$firstDay - $lastDay",
                sourceLabel = "ESPN • Doğrulanmış Sonuçlar",
                matches = mapped
            )
            _previousWeekReport.value = report
            Result.success(report)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Result.failure(
                IllegalStateException("Geçen haftanın sonuçları için ESPN bağlantısı kurulamadı.")
            )
        }
    }

    private fun EspnEvent.toBulletinMatchDto(
        matchNumber: Int,
        leagueLabel: String,
        istanbulTz: TimeZone
    ): BulletinMatchDto? {
        val competition = competitions.firstOrNull() ?: return null
        val home = competition.competitors.firstOrNull { it.homeAway.equals("home", ignoreCase = true) }
            ?: return null
        val away = competition.competitors.firstOrNull { it.homeAway.equals("away", ignoreCase = true) }
            ?: return null
        val homeName = home.team.displayName.ifBlank { home.team.shortDisplayName }.trim()
        val awayName = away.team.displayName.ifBlank { away.team.shortDisplayName }.trim()
        if (homeName.isBlank() || awayName.isBlank()) return null

        val statusLabel = when (resolveStatus()) {
            MatchStatus.FINISHED -> "FINISHED"
            MatchStatus.LIVE, MatchStatus.HALF_TIME -> "LIVE"
            MatchStatus.UPCOMING -> "UPCOMING"
        }
        return BulletinMatchDto(
            matchNumber = matchNumber,
            homeTeam = homeName.uppercase(Locale.ROOT),
            awayTeam = awayName.uppercase(Locale.ROOT),
            matchDate = formatIsoDateForBulletin(competition.date ?: date, istanbulTz),
            league = leagueLabel,
            venue = competition.venue?.fullName.orEmpty(),
            status = statusLabel,
            liveOdds = LiveBettingOddsDto(
                homeWinOdd = 2.15,
                drawOdd = 3.25,
                awayWinOdd = 3.30,
                doubleChance1X = 1.32,
                doubleChance12 = 1.28,
                doubleChanceX2 = 1.62
            ),
            probabilities = MatchProbabilitiesDto(
                homeProbability = 42,
                drawProbability = 29,
                awayProbability = 29
            )
        )
    }

    override suspend fun getWeeklyBulletin(forceRefresh: Boolean): Result<WeeklyBulletinResponse> =
        withContext(Dispatchers.IO) {
            try {
                if (!forceRefresh && _cachedBulletin.value.isPlayable()) {
                    return@withContext Result.success(_cachedBulletin.value!!)
                }

                val response = apiService.getCurrentWeeklyBulletin()
                if (response.isSuccessful && response.body() != null) {
                    val isOfflineInterceptorPayload =
                        response.raw().message == "OK - Offline Resilient Bulletin"
                    val bulletin = if (preferTurkishLeagueBulletin &&
                        apiService === NetworkModule.apiService &&
                        isOfflineInterceptorPayload
                    ) {
                        defaultOfflineBulletin()
                    } else {
                        response.body()!!
                    }
                    if (!bulletin.isPlayable()) {
                        _cachedBulletin.value = null
                        return@withContext Result.failure(NoNewBulletinException())
                    }
                    _cachedBulletin.value = bulletin
                    Result.success(bulletin)
                } else if (apiService === NetworkModule.apiService) {
                    // Fallback to offline standard bulletin only when using default built-in prototype endpoint
                    val fallback = defaultOfflineBulletin()
                    _cachedBulletin.value = fallback
                    Result.success(fallback)
                } else {
                    _cachedBulletin.value = null
                    Result.failure(NoNewBulletinException())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (apiService === NetworkModule.apiService) {
                    val fallback = _cachedBulletin.value?.takeIf { it.isPlayable() }
                        ?: defaultOfflineBulletin()
                    _cachedBulletin.value = fallback
                    Result.success(fallback)
                } else {
                    _cachedBulletin.value = null
                    Result.failure(NoNewBulletinException())
                }
            }
        }

    override suspend fun getBulletinByWeek(weekNumber: Int): Result<WeeklyBulletinResponse> =
        withContext(Dispatchers.IO) {
            try {
                val response = apiService.getBulletinByWeek(weekNumber)
                if (response.isSuccessful && response.body() != null) {
                    val isOfflineInterceptorPayload =
                        response.raw().message == "OK - Offline Resilient Bulletin"
                    val bulletin = if (preferTurkishLeagueBulletin &&
                        apiService === NetworkModule.apiService &&
                        isOfflineInterceptorPayload
                    ) {
                        defaultOfflineBulletin(weekNumber)
                    } else {
                        response.body()!!
                    }
                    Result.success(bulletin)
                } else {
                    val fallback = defaultOfflineBulletin(weekNumber)
                    Result.success(fallback)
                }
            } catch (e: Exception) {
                Result.success(defaultOfflineBulletin(weekNumber))
            }
        }

    override suspend fun refreshLiveOdds(): Result<List<BulletinMatchDto>> =
        withContext(Dispatchers.IO) {
            try {
                val response = apiService.getLiveOdds()
                if (response.isSuccessful && response.body() != null) {
                    val updatedMatches = response.body()!!
                    // Update in-memory cached bulletin with refreshed live odds
                    _cachedBulletin.value?.let { current ->
                        _cachedBulletin.value = current.copy(matches = updatedMatches)
                    }
                    Result.success(updatedMatches)
                } else {
                    Result.success(_cachedBulletin.value?.matches ?: emptyList())
                }
            } catch (e: Exception) {
                Result.success(_cachedBulletin.value?.matches ?: emptyList())
            }
        }

    override suspend fun getDomainMatches(forceRefresh: Boolean): Result<List<TotoMatch>> {
        val result = getWeeklyBulletin(forceRefresh)
        return result.fold(
            onSuccess = { bulletin ->
                if (!bulletin.isPlayable()) {
                    Result.failure(NoNewBulletinException())
                } else {
                    Result.success(bulletin.matches.map { it.toDomainTotoMatch() })
                }
            },
            onFailure = { error ->
                Result.failure(
                    if (error is NoNewBulletinException) error else NoNewBulletinException()
                )
            }
        )
    }
}
